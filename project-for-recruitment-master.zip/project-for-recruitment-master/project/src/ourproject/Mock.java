package ourproject;

public @interface Mock {

}
